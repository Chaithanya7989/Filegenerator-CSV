﻿ 
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using WinSCP;

namespace CSV.CsvGeneration
{
    public class SFTPTransfer
    {
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<Worker> _logger;

        public SFTPTransfer(IConfiguration iconfiguration, ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<Worker>();
            _iconfiguration = iconfiguration;
            SFTP_FileTransfer();
        }
        public void SFTP_FileTransfer()
        {
            try
            {
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = _iconfiguration.GetSection("FileServerInfo").GetSection("Host").Value,
                    UserName = _iconfiguration.GetSection("FileServerInfo").GetSection("UserName").Value,
                    Password = _iconfiguration.GetSection("FileServerInfo").GetSection("Password").Value,
                    PortNumber = Convert.ToInt32(_iconfiguration.GetSection("FileServerInfo").GetSection("Port").Value),
                    SshHostKeyFingerprint = _iconfiguration.GetSection("FileServerInfo").GetSection("SshHostKeyFingerprint").Value
                };
                using (Session session = new Session())
                {
                    session.Open(sessionOptions);
                    TransferOptions transferOptions = new TransferOptions();
                    transferOptions.TransferMode = TransferMode.Binary;
                    TransferOperationResult transferResult;
                    var path = _iconfiguration.GetSection("Pathdata").GetSection("Path").Value;
                    IConfigurationSection myArraySection = _iconfiguration.GetSection("ExportFileToSFTP");

                    var itemArray = myArraySection.AsEnumerable();
                    transferResult = session.PutFiles(path, "/local/Resulticks_File_Exchange/Forget_Customer/Trans_Croma", false, transferOptions);
                    transferResult.Check();
                    foreach (TransferEventArgs transfer in transferResult.Transfers)
                    {
                        Console.WriteLine("upload of {0} succeeded", transfer.FileName);
                    }
                }
            }
            catch (Exception ex)
            { 
            Log.Error(ex, "Error Message");
          
            }
        }
    }
}
