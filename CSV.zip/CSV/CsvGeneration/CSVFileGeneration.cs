﻿
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using MySql.Data.MySqlClient;
using Serilog;
using System;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Net;

namespace CSV.CsvGeneration
{
    public class CSVFileGeneration
    {
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<Worker> _logger;
        public CSVFileGeneration(IConfiguration iconfiguration, ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<Worker>();
            _iconfiguration = iconfiguration;
            CsvGeneration();
            Download_File();
        }
        public void CsvGeneration()
        {
            var logpath = _iconfiguration.GetSection("Path_Information").GetSection("LogPath").Value;
            Log.Logger = new LoggerConfiguration().WriteTo.File(logpath).CreateLogger();
            Log.Information("sample information");
            var Con = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("MySql_Connection").Value;
            string selectQuery = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("Querystring").Value;
            var table = ReadTable(Con, selectQuery);
            var path = _iconfiguration.GetSection("Path_Information").GetSection("Path").Value;
            WriteToFile(table, path, false, ", ");
        }
        public static DataTable ReadTable(string connectionString, string selectQuery)
        {
            var returnValue = new DataTable();
            var conn = new MySqlConnection(connectionString);
            try
            {
                conn.Open();
                var command = new MySqlCommand(selectQuery, conn);
                using (var adapter = new MySqlDataAdapter(command))
                {
                    adapter.Fill(returnValue);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
                throw ex;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
            return returnValue;
        }
        public static void WriteToFile(DataTable dataSource, string fileOutputPath, bool firstRowIsColumnHeader = false, string seperator = ";")
        {
            try
            {
                var sw = new StreamWriter(fileOutputPath, false);
                int icolcount = dataSource.Columns.Count;
                //var tcname = dataSource.Columns.Add("RT_Processed_Date");
                //var tcname1 = dataSource.Columns.Add("Status");
                if (!firstRowIsColumnHeader)
                {
                    int data = dataSource.Columns.Count;
                    for (int i = 0; i < data; i++)
                    {
                        sw.Write(dataSource.Columns[i]);
                        if (i < data - 1)
                            sw.Write(seperator);
                    }
                    sw.Write(sw.NewLine);
                }
                foreach (DataRow drow in dataSource.Rows)
                {
                    int data = dataSource.Columns.Count;

                    for (int i = 0; i < data; i++)
                    {
                        //if (drow[10] == null || drow[10].ToString() == string.Empty)
                        //{
                        //    drow[10].SetValue = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        //    drow[11] = "Completed";
                        //}
                        if (!Convert.IsDBNull(drow[i]))
                            sw.Write(drow[i].ToString());
                        if (i < data - 1)
                            sw.Write(seperator);
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
                throw ex;
            }
        }
        public void Download_File()
        {
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = _iconfiguration.GetSection("Dremio_Download").GetSection("Log_Path").Value;
            try
            {
                //Declare Variables and provide values
                string fileNamePart = _iconfiguration.GetSection("Dremio_Download").GetSection("FileNamePart").Value;//Datetime will be added to it
                string destinationFolder = _iconfiguration.GetSection("Dremio_Download").GetSection("DestinationFolder").Value;
                string tableName = _iconfiguration.GetSection("Dremio_Download").GetSection("TableName").Value;
                string fileDelimiter = _iconfiguration.GetSection("Dremio_Download").GetSection("FileDelimiter").Value; //You can provide comma or pipe or whatever you like
                string fileExtension = _iconfiguration.GetSection("Dremio_Download").GetSection("FileExtension").Value; //Provide the extension you like such as .txt or .csv
                //Create Connection to SQL Server in which you like to load files
                var Connection = _iconfiguration.GetSection("Dremio_ConnectionString").GetSection("Forgot_Customer").Value;
                OdbcConnection DbConnection = new OdbcConnection(Connection);
                //Read data from table or view to data table
                string query = "Select * From " + tableName;
                OdbcCommand DbCommand = DbConnection.CreateCommand();
                OdbcCommand odbcCommand = new OdbcCommand(query, DbConnection);
                DbConnection.Open();
                DataTable d_table = new DataTable();
                d_table.Load(odbcCommand.ExecuteReader());
                DbConnection.Close();
                //Prepare the file path 
                string FileFullPath = destinationFolder + "\\" + fileNamePart + "_" + datetime + fileExtension;
                StreamWriter sw = null;
                sw = new StreamWriter(FileFullPath, false);
                // Write the Header Row to File
                int ColumnCount = d_table.Columns.Count;
                for (int ic = 0; ic < ColumnCount; ic++)
                {
                    sw.Write(d_table.Columns[ic]);
                    if (ic < ColumnCount - 1)
                    {
                        sw.Write(fileDelimiter);
                    }
                }
                sw.Write(sw.NewLine);
                // Write All Rows to the File
                foreach (DataRow dr in d_table.Rows)
                {
                    for (int ir = 0; ir < ColumnCount; ir++)
                    {
                        if (!Convert.IsDBNull(dr[ir]))
                        {
                            sw.Write(dr[ir].ToString());
                        }
                        if (ir < ColumnCount - 1)
                        {
                            sw.Write(fileDelimiter);
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception exception)
            {
                using (StreamWriter sw = File.CreateText(LogFolder
                    + "\\" + "ErrorLog_" + datetime + ".log"))
                {
                    sw.WriteLine(exception.ToString());
                }
            }
        }
    }
}

